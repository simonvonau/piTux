# PiTux

A little supertux/mario2D remake which aims to be loaded on a raspberry.
It's made in C with code:Blocks and the SDL2 librairy, but without graphic accelerating because I am not sure all raspberry will appreciate it...


## Getting Started

Not yet available.

### Prerequisites

Not yet available.

### Installing

Not yet available.


## Authors

* **Simon Vonau**

See also the original supertux project at https://github.com/SuperTux/supertux/wiki where I got all my sprites.



